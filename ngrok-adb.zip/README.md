One shot install command:
```
wget https://raw.githubusercontent.com/mastercodeon314/ngrok-adb/master/ngrok-adb-installer.sh && chmod 777 ngrok-adb-installer.sh && ./ngrok-adb-installer.sh
```

Uninstall command:
```
ngrok-adb-uninstall
```